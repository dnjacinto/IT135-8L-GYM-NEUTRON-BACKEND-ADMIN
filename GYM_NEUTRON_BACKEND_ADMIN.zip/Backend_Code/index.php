<?php
include_once './config/connection.php';
include_once './objects/member.php';
include_once './objects/membership.php';
include_once './objects/trainer.php';

$database = new Database();
$db = $database->getConnection();

$member = new Member($db);
$plan = new Membership($db);
$trainer = new Trainer($db);

$plans = $plan->load_plans();

/* The API portion I suppose*/
if ($member->create_member('rudnick', 'test', '09242345678', 'test@gmail.com', '12345', 'Monthly', $plans)) {
	echo "hello";
}


//$trainer->create_trainer('rudnick', 'last name', 'yourmom@gmail.com', '09123456789', '12345');
//$trainer->create_trainer('test', 'last name 2', 'yourmom2@gmail.com', '09123456784', '12345');
//$trainer->create_trainer('test 3', 'last name 4', 'yourmom4@gmail.com', '09123456769', '12345');

echo $trainer->load_trainers();
?>