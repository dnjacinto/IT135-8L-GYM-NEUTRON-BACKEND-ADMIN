<?php
class Member{
	// database connections
	private $conn;
	private $table_name = 'member';
	private $table_junc_name = 'member_trainer_relation';
	
	// member details
	private $m_id;
	private $m_first_name;
	private $m_last_name;
	private $m_mobile_number;
	private $m_email;
	private $m_password;
	private $m_mem_id;
	private $m_mem_start;
	private $m_mem_end;
	private $created_on;
	private $editted_on;
	
	private $trainers = array();
	
	function __construct($db) {
		$this->conn = $db;
	}
	
	private function generateID() {
		$this->m_id = strftime('%Y') . mt_rand(10000, 99999);
	}
	
	// creating a member if it doesn't exist
	function create_member($fname, $lname, $mobile, $email, $password, $membership, $mem_json) {
		$command_load = "select * from `" . $this->table_name . "` where `email` = '" . $email . "';"; // used for checking if an email exist; returns false
		$res = mysqli_query($this->conn, $command_load);

		if (mysqli_num_rows($res) == 0) {
			$this->generateID();
			$this->m_first_name = $fname;
			$this->m_last_name = $lname;
			$this->m_mobile_number = $mobile;
			$this->m_email = $email;
			$this->m_password = $password;
			
			// get membership id
			$plans = json_decode($mem_json, true)["plan_types"];
			foreach($plans as $plan) {
				if ($plan['name'] == $membership) {
					// membership type
					$this->m_mem_id = $plan['id'];
					
					// date
					$date = date("Y-m-d H:i:s");
					$this->m_mem_start = $date;
					$this->m_mem_end = date("Y-m-d H:i:s", strtotime($date . " + " . $plan['length'] . " days"));
				}
			}
			
			// add user to the database
			$command_insert = "insert into `" . $this->table_name . 
							  "` (`member_id`,
								  `first_name`,
								  `last_name`,
								  `mobile_number`,
								  `email`,
								  `password`,
								  `membership_id`,
								  `membership_start`,
								  `membership_end`,
								  `created_on`,
								  `editted_on`) VALUES ('" .
							  $this->m_id . "', '" .
							  $this->m_first_name . "', '" .
							  $this->m_last_name . "', '" .
							  $this->m_mobile_number . "', '" .
							  $this->m_email . "', '" .
							  $this->m_password . "', '" .
							  $this->m_mem_id . "', '" .
							  $this->m_mem_start ."', '" .
							  $this->m_mem_end . "', 
							  current_timestamp(), '" .
							  date("Y-m-d H:i:s") . "');";
							  
			$res = mysqli_query($this->conn, $command_insert);
			
			if ($res) {
				return true;
			}
			
			return false;
		} 
		
		return false;
	}	
	
	// load member from database
	function load_member($email, $id = null) {
		$command_load = "select * from `" . $this->table_name . "` where `email` = '" . $email . "' or `member_id` = '" . $id . "';";
		$res = mysqli_query($this->conn, $command_load);
		
		$member = array();
		$member["member_details"] = array();
		while($row = mysqli_fetch_assoc($res)) {
			extract($row);
			
			$trainers = $this->get_list_of_trainers($member_id);
			$member_details = array(
				"id" => $member_id,
				"first_name" => $first_name,
				"last_name" => $last_name,
				"mobile_number" => $mobile_number,
				"email" => $email,
				"password" => $password,
				"membership_id" => $membership_id,
				"membership_start" => $membership_start,
				"membership_end" => $membership_end,
				"trainers" => $trainers,
				"created_on" => $created_on,
				"editted_on" => $editted_on
			);
			
			array_push($member["member_details"], $member_details);
		}		
			
		if (empty($member["member_details"])) {
			array_push($member["member_details"], array("message" => "member does not exist",
														"email" => $email,
														"password" => null));
			return json_encode($member);
		} else {
			$this->m_id = $member["member_details"][0]['id'];
			$this->m_first_name = $member["member_details"][0]['first_name'];
			$this->m_last_name = $member["member_details"][0]['last_name'];
			$this->m_mobile_number = $member["member_details"][0]['mobile_number'];
			$this->m_email = $member["member_details"][0]['email'];
			$this->m_password = $member["member_details"][0]['password'];
			$this->m_mem_id = $member["member_details"][0]['membership_id'];
			$this->m_mem_start = $member["member_details"][0]['membership_start'];
			$this->m_mem_end = $member["member_details"][0]['membership_end'];
			$this->trainers = $member["member_details"][0]['trainers'];
			$this->created_on = $member["member_details"][0]['created_on'];
			$this->editted_on = $member["member_details"][0]['editted_on'];
			return json_encode($member);
		}
	}
	
	// load all members
	function load_members() {
		$command_load = "select * from `" . $this->table_name . "`;";
		$res = mysqli_query($this->conn, $command_load);
		
		
		$members = array();
		$members["member_details"] = array();
		while($row = mysqli_fetch_assoc($res)) {
			extract($row);
				
			$member_details = array(
				"id" => $member_id,
				"first_name" => $first_name,
				"last_name" => $last_name,
				"mobile_number" => $mobile_number,
				"email" => $email,
				"password" => $password,
				"membership_id" => $membership_id,
				"membership_start" => $membership_start,
				"membership_end" => $membership_end,
				"created_on" => $created_on,
				"editted_on" => $editted_on
			);
				
			array_push($members["member_details"], $member_details);
		}
		
		
		if (empty($members["member_details"])) {
			array_push($members["member_details"], array("message" => "no existing members"));
			return json_encode($members);
		} 
		
		return json_encode($members);
	}
	
	// update the member's details
	function edit_member($refEmail, $fname, $lname, $email, $mobile, $password) {
		
		if ($this->m_email == $refEmail) {
			$this->m_first_name = $fname;
			$this->m_last_name = $lname;
			$this->m_email = $email;
			$this->m_mobile_number = $mobile;
			$this->m_password = $password;
			$this->editted_on = date("Y-m-d H:i:s");
			
			$command_update = "update " . $this->table_name . " set 
							  `first_name` = '" . $this->m_first_name . "', 
							  `last_name` = '" .$this->m_last_name . "', 
							  `email` = '" . $this->m_email . "', 
							  `mobile_number` = '" . $this->m_mobile_number . "', 
							  `password` = '" . $this->m_password . "', 
							  `editted_on` = '" . date("Y-m-d H:i:s") . "' where
							  `member_id` = " . $this->m_id . ";";
							  
			$res = mysqli_query($this->conn, $command_update);
			if ($res) {
				return true;
			} 
			
			return false;
		} 
		
		return false;
	}
	
	// extending of membership
	function extend_membership($mem_json, $membership) {
		$plans = json_decode($mem_json, true)["plan_types"];
		$flag = false;
		
		foreach($plans as $plan) {
			if($plan['name'] == $membership){
				$this->m_mem_id = $plan['id'];
				$date = date("Y-m-d H:i:s");
				$this->m_mem_end = date("Y-m-d H:i:s", strtotime($this->m_mem_end . " + " . $plan['length'] . " days"));				
				
				$flag = true;
				break;
			}
		}
		
		// update membership details
		$command_update = "update " . $this->table_name . " set 
						  `membership_id` = '" . $this->m_mem_id . "',
						  `membership_start` = '" . $this->m_mem_start . "',
						  `membership_end` = '" . $this->m_mem_end . "', 
						  `editted_on` = '" . date("Y-m-d H:i:s") . "' where
						  `member_id` = " . $this->m_id . ";";
		
		$res = mysqli_query($this->conn, $command_update);
		if ($res && $flag) {
			return true;
		} 
		
		return false;
	}

	// hiring a trainer
	function hire_trainer($trainers_json, $id) {
		$trainers = json_decode($trainers_json, true)["trainer_details"];
		$trainer_id = null;
		
		if (!in_array($id, $this->trainers)) {
			foreach($trainers as $trainer) {
				if($trainer['id'] == $id) {
					$trainer_id = $trainer['id'];
					break;
				}
			}
		}
		
		if ($trainer_id != null) {
			// update trainer id
			$command_load = "insert into " . $this->table_junc_name . 
							" (`member_id`, 
							   `trainer_id`) VALUES ('" .
							$this->m_id . "', '" .
							$trainer_id . "');";
			
			$res = mysqli_query($this->conn, $command_load);
			
			if ($res) {
				return true;
			} 
			
			return false;
		} 
		
		return false;
	}
	
	function get_list_of_trainers($id) {
		$command_load = "select * from `" . $this->table_junc_name . "` 
						 where `member_id` = '" . $id . "';";
						 
		$res = mysqli_query($this->conn, $command_load);
		
		$listTrainers = array();
		while($row = mysqli_fetch_assoc($res)) {
			extract($row);
			
			array_push($listTrainers, $trainer_id);
		}
		
		return $listTrainers;
	}
	
}
?>