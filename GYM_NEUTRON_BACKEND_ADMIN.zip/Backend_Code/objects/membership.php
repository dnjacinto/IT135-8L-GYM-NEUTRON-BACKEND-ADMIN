<?php
class Membership{
	// database connection
	private $conn;
	private $table_name = "membership_plan";
	
	// membership details
	private $mp_id;
	private $mp_name;
	private $mp_price;
	private $mp_length;
	private $created_on;
	private $editted_on;
	
	function __construct($db) {
		$this->conn = $db;
	}
	
	private function generateID() {
		$this->mp_id = mt_rand(100000, 999999);
	}
	
	function create_membership_plan($name, $length, $price){
		$command_load = "select * from `" . $this->table_name . "` where `membership_name` = '" . $name . "';"; // used for checking if the username exist; returns false
		$res = mysqli_query($this->conn, $command_load);
		
		if (mysqli_num_rows($res) == 0) {
			$this->generateID();
			$this->mp_name = $name;
			$this->mp_length = $length;
			$this->mp_price = $price;

			$command_insert = "insert into `" . $this->table_name .
							  "` (`membership_id`, `membership_name`, `membership_length`, `membership_price`, `created_on`, `editted_on`) VALUES ('" .
							  $this->mp_id . "', '" .
							  $this->mp_name . "', '" .
							  $this->mp_length . "', '" .
							  $this->mp_price . "', current_timestamp(), '" .
							  date("Y-m-d H:i:s") . "');";
							  
			
			$res = mysqli_query($this->conn, $command_insert);
			if ($res) {
				return true;
			} 
			return false;
			
		} 
		return false;
	}
	
	function load_plans() {
		$command_load = "select * from `" . $this->table_name . "`;";
		$res = mysqli_query($this->conn, $command_load);
		
		$plans = array();
		$plans["plan_types"] = array();
		while($row = mysqli_fetch_assoc($res)) {
			extract($row);
				
			$plan_type = array(
				"id" => $membership_id,
				"name" => $membership_name,
				"length" => $membership_length,
				"price" => $membership_price,
				"created_on" => $created_on,
				"editted_on" => $editted_on
			);
				
			array_push($plans["plan_types"], $plan_type);
		}
		
		
		if (empty($plans["plan_types"])) {
			array_push($plans["plan_types"], array("message" => "empty membership plans"));
			return false;
		} 
		
		return json_encode($plans);
	}
}
?>