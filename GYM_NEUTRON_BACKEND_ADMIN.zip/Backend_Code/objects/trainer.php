<?php
class Trainer {
	// database connections
	private $conn;
	private $table_name = 'trainer';
	
	// member details
	private $t_id;
	private $t_username;
	private $t_password;
	private $t_first_name;
	private $t_last_name;
	private $t_mobile_number;
	private $t_email;
	private $t_schedule;
	private $created_on;
	private $editted_on;
	
	function __construct($db) {
		$this->conn = $db;
	}
	
	private function generateID() {
		$this->t_id = mt_rand(10000, 99999) . strftime('%Y');
	}
	
	function create_trainer($fname, $lname, $mobile, $email, $schedule, $password) {
		$command_load = "select * from `" . $this->table_name . "` where `email` = '" . $email . "';"; // used for checking if the username exist; returns false
		$res = mysqli_query($this->conn, $command_load);
		
		if (mysqli_num_rows($res) == 0) {
			$this->generateID();
			$this->t_first_name = $fname;
			$this->t_last_name = $lname;
			$this->t_mobile_number = $mobile;
			$this->t_email = $email;	
			$this->t_schedule = $schedule;
			$this->t_password = $password;
			
			// add user to the database
			$command_insert = "insert into `" . $this->table_name . 
							  "` (`trainer_id`,
								  `first_name`,
								  `last_name`,
								  `mobile_number`,
								  `email`,
								  `schedule`,
								  `password`,
								  `created_on`,
								  `editted_on`) VALUES ('" .
							  $this->t_id . "', '" . 
							  $this->t_first_name . "', '" . 
							  $this->t_last_name . "', '" . 
							  $this->t_mobile_number . "', '" . 
							  $this->t_email . "', '" .
							  $this->t_schedule . "', '" .
							  $this->t_password . "', 
							  current_timestamp(), '" . 
							  date("Y-m-d H:i:s") . "');" ;
			
			$res = mysqli_query($this->conn, $command_insert);
			
			if ($res) {
				return true;
			} 
			
			return false;
		} 
		
		return false;
	}	
	
	function edit_trainer($refEmail, $fname, $lname, $email, $mobile, $schedule, $password) {
		
		if ($this->t_email == $refEmail) {
			$this->t_first_name = $fname;
			$this->t_last_name = $lname;
			$this->t_email = $email;
			$this->t_mobile_number = $mobile;
			$this->t_password = $password;
			$this->t_schedule = $schedule;
			$this->editted_on = date("Y-m-d H:i:s");
			
			$command_update = "update `" . $this->table_name . "` set 
							  `first_name` = '" . $this->t_first_name . "', 
							  `last_name` = '" .$this->t_last_name . "', 
							  `email` = '" . $this->t_email . "', 
							  `mobile_number` = '" . $this->t_mobile_number . "', 
							  `schedule` = '" . $this->t_schedule . "',
							  `password` = '" . $this->t_password . "', 
							  `editted_on` = '" . date("Y-m-d H:i:s") . "' where
							  `trainer_id` = '" . $this->t_id . "';";
							  			  
			$res = mysqli_query($this->conn, $command_update);
			if ($res) {
				return true;
			} 
			
			return false;
		} 
		
		return false;
	}
	
	function load_trainer($email) {
		$command_load = "select * from `" . $this->table_name . "` where `email` = '" . $email . "';";
		$res = mysqli_query($this->conn, $command_load);
		
		$trainer = array();
		$trainer["trainer_details"] = array();
		while($row = mysqli_fetch_assoc($res)) {
			extract($row);
			
			$trainer_details = array(
				"id" => $trainer_id,
				"first_name" => $first_name,
				"last_name" => $last_name,
				"email" => $email,
				"mobile_number" => $mobile_number,
				"schedule" => $email,
				"password" => $password,
				"created_on" => $created_on,
				"editted_on" => $editted_on
			);
			
			array_push($trainer["trainer_details"], $trainer_details);
		}		
			
		if (empty($trainer["trainer_details"])) {
			array_push($trainer["trainer_details"], array("message" => "trainer does not exist"));
			return json_encode($trainer);
		} else {
			$this->t_id = $trainer["trainer_details"][0]['id'];
			$this->t_first_name = $trainer["trainer_details"][0]['first_name'];
			$this->t_last_name = $trainer["trainer_details"][0]['last_name'];
			$this->t_mobile_number = $trainer["trainer_details"][0]['mobile_number'];
			$this->t_email = $trainer["trainer_details"][0]['email'];
			$this->t_schedule = $trainer["trainer_details"][0]['schedule'];
			$this->t_password = $trainer["trainer_details"][0]['password'];
			$this->created_on = $trainer["trainer_details"][0]['created_on'];
			$this->editted_on = $trainer["trainer_details"][0]['editted_on'];
			return json_encode($trainer);
		}
	}
	
	function load_trainers() {
		$command_load = "select * from `" . $this->table_name . "`;";
		$res = mysqli_query($this->conn, $command_load);
		
		$trainers = array();
		$trainers["trainer_details"] = array();
		while($row = mysqli_fetch_assoc($res)) {
			extract($row);
				
			$trainer_details = array(
				"id" => $trainer_id,
				"first_name" => $first_name,
				"last_name" => $last_name,
				"email" => $email,
				"mobile_number" => $mobile_number,
				"schedule" => $schedule,
				"password" => $password,
				"created_on" => $created_on,
				"editted_on" => $editted_on
			);
				
			array_push($trainers["trainer_details"], $trainer_details);
		}
		
		
		if (empty($trainers["trainer_details"])) {
			array_push($trainers["trainer_details"], array("message" => "empty trainers"));
			return false;
		}
		
		return json_encode($trainers);
	}
}
?>