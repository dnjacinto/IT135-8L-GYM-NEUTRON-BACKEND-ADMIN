<?php
    class Transaction{
        //Database
        private $conn;
        private $table = 'transaction';

        //showAllMembers Properties
        private $trans_id;
        private $membership_id;
		private $member_id;
        private $purchase_date;

        //Constructor with DB
        public function __construct($db){
            $this->conn = $db;
        }
		
		private function generateID(){
            $this->trans_id = strftime('%y%d') . mt_rand(10000, 99999);
        }
		
		//Create Transaction
        public function createTransaction($membership_id, $member_id){
            $this->generateID();
            $this->membership_id = $membership_id;
            $this->member_id = $member_id;
			$this->purchase_date = date("Y-m-d H:i:s");

            //Add Transaction to database
            $command_insert = "INSERT INTO `" . $this->table . 
							  "` (`transaction_id`,
								  `membership_id`,
								  `member_id`,
								  `purchase_date`) VALUES ('" .
								$this->trans_id . "', '" . 
								$this->membership_id . "', '" . 
								$this->member_id . "', '" . 
								$this->purchase_date . "');";				
			
            $res = mysqli_query($this->conn, $command_insert);
            if ($res) {
				return true;
			} 
			
			return false;
            
        }

        //Get All Transactions
        public function read(){
            //Create query
            $query = 'SELECT * FROM `' . $this->table . '`;';

            //Run query
            $res = mysqli_query($this->conn, $query);
			
			$transactions = array();
			$transactions["transaction_list"] = array();
			while($row = mysqli_fetch_assoc($res)) {
				extract($row);
					
				$transaction_list = array(
					'transaction_id' => $transaction_id,
					'membership_id' => $membership_id,
					'member_id' => $member_id,
					'purchase_date' => $purchase_date
				);
					
				array_push($transactions["transaction_list"], $transaction_list);
			}
			
			if (empty($transactions["transaction_list"])) {
				array_push($transactions["transaction_list"], array("message" => "No Transactions"));
				return json_encode($transactions);
			} 
			
			return json_encode($transactions); 
        }

        //Get range of transaction
        public function readFilter($from_date, $to_date){
			$to = date("Y-m-d", strtotime($to_date . " + 1 days"));
			
            //Create query
            $query = "SELECT * FROM `" . $this->table . "`
            WHERE `purchase_date` BETWEEN '" . $from_date . "' AND '" . $to . "';";

            // Run the query
            $res = mysqli_query($this->conn, $query);
			
			$transactions = array();
			$transactions["transaction_list"] = array();
			while($row = mysqli_fetch_assoc($res)) {
				extract($row);
					
				$transaction_list = array(
					'transaction_id' => $transaction_id,
					'membership_id' => $membership_id,
					'member_id' => $member_id,
					'purchase_date' => $purchase_date
				);
					
				array_push($transactions["transaction_list"], $transaction_list);
			}
			
			if (empty($transactions["transaction_list"])) {
				array_push($transactions["transaction_list"], array("message" => "No Transactions"));
				return json_encode($transactions);
			} 
			
			return json_encode($transactions);          
        }
    }
?>