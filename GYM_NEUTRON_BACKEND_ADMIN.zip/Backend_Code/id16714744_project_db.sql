-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 12, 2021 at 05:35 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id16714744_project_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `member_id` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_number` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `membership_id` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `membership_start` datetime NOT NULL,
  `membership_end` datetime NOT NULL,
  `created_on` datetime NOT NULL,
  `editted_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `first_name`, `last_name`, `mobile_number`, `email`, `password`, `membership_id`, `membership_start`, `membership_end`, `created_on`, `editted_on`) VALUES
('202118050', 'Hiroyuki', 'Sawano', '09182814917', 'sawanohiroyuki@gmail.com', '123', '198232', '2021-05-12 16:47:25', '2021-06-11 16:47:25', '2021-05-12 16:47:25', '2021-05-12 16:47:25'),
('202119992', 'donaire', 'test', '09242345678', 'test@gmail.com', '123', '198232', '2021-05-10 06:32:02', '2030-09-17 06:32:02', '2021-05-10 06:32:02', '2021-05-12 12:39:19'),
('202126330', 'john', 'Smith', '09239992223', 'johnSmith1@google.com', '123456', '198232', '2021-05-10 06:52:15', '2021-06-09 06:52:15', '2021-05-10 06:52:15', '2021-05-10 07:43:19'),
('202135790', 'Stephen', 'Smith', '09283746172', 'stephen@smith.com', '1234567', '198231', '2021-05-12 11:57:13', '2031-06-05 11:57:13', '2021-05-12 11:57:13', '2021-05-12 17:12:59'),
('202167544', 'Lean', 'Gaurana', '09239992223', 'test@test.com', '123', '198232', '2021-05-10 07:13:08', '2028-02-01 07:13:08', '2021-05-10 07:13:08', '2021-05-12 09:42:42'),
('202170640', 'Miguel', 'Abundo', '09986422426', 'miguel_abundo@hotmail.com', '12345', '198233', '2021-05-12 12:38:29', '2023-05-19 12:38:29', '2021-05-12 12:38:29', '2021-05-12 14:53:25'),
('202173721', 'Seom', 'Tst', '09876543210', 'sem@tst.com', '123', '198231', '2021-05-12 12:03:21', '2021-05-19 12:03:21', '2021-05-12 12:03:21', '2021-05-12 12:03:21'),
('202192046', 'steven', 'mike', '09239991111', 'mikeSteven@gmail.com', '12345', '198232', '2021-05-10 06:53:28', '2021-06-09 06:53:28', '2021-05-10 06:53:28', '2021-05-10 06:53:28'),
('202194545', 'Michael', 'Abundo', '09186422426', 'michael_abundo@gmail.com', '123456789', '198233', '2021-05-12 15:15:22', '2022-06-11 15:15:22', '2021-05-12 15:15:22', '2021-05-12 15:17:23'),
('202195482', 'Ash', 'Ketchum', '09144527284', 'ash_ketchum20@gmail.com', 'pokemonmaster', '198232', '2021-05-12 16:50:35', '2021-06-11 16:50:35', '2021-05-12 16:50:35', '2021-05-12 16:50:35');

-- --------------------------------------------------------

--
-- Table structure for table `membership_plan`
--

CREATE TABLE `membership_plan` (
  `membership_id` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `membership_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `membership_length` int(11) NOT NULL,
  `membership_price` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `editted_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `membership_plan`
--

INSERT INTO `membership_plan` (`membership_id`, `membership_name`, `membership_length`, `membership_price`, `created_on`, `editted_on`) VALUES
('198231', 'Weekly', 7, 500, '2021-05-10 13:39:42', '2021-05-10 13:39:42'),
('198232', 'Monthly', 30, 1000, '2021-05-10 05:42:03', '2021-05-10 05:42:03'),
('198233', 'Annually', 365, 1500, '2021-05-10 05:42:03', '2021-05-10 05:42:03');

-- --------------------------------------------------------

--
-- Table structure for table `member_trainer_relation`
--

CREATE TABLE `member_trainer_relation` (
  `member_id` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `trainer_id` varchar(9) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `member_trainer_relation`
--

INSERT INTO `member_trainer_relation` (`member_id`, `trainer_id`) VALUES
('202119992', '816802021'),
('202119992', '934932021'),
('202126330', '934932021'),
('202167544', '829832021'),
('202167544', '934932021'),
('202167544', '151872021'),
('202167544', '776312021'),
('202167544', '638782021'),
('202167544', '231352021'),
('202167544', '439722021'),
('202167544', '924652021'),
('202167544', '816802021'),
('202167544', '876392021'),
('202167544', '522752021'),
('202167544', '412482021'),
('202167544', '256722021'),
('202179384', '151872021'),
('202164066', '231352021'),
('202164066', '256722021'),
('202119992', '415462021'),
('202119992', '998852021'),
('202170640', '151872021'),
('202170640', '924652021'),
('202194545', '142652021'),
('202135790', '151872021'),
('202135790', '231352021');

-- --------------------------------------------------------

--
-- Table structure for table `trainer`
--

CREATE TABLE `trainer` (
  `trainer_id` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_number` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `schedule` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_on` datetime NOT NULL,
  `editted_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `trainer`
--

INSERT INTO `trainer` (`trainer_id`, `first_name`, `last_name`, `mobile_number`, `email`, `schedule`, `password`, `created_on`, `editted_on`) VALUES
('108782021', 'Mike', 'Hannigan', '09876549876', 'mikehannigan@gmail.com', 'TTHS', '00000000000', '2021-05-12 16:50:56', '2021-05-12 16:50:56'),
('142652021', 'Mike', 'Gaurana', '09278971273', 'we@come.com', 'MWF', '00000000000', '2021-05-12 08:50:13', '2021-05-12 08:50:13'),
('151872021', 'Steven', 'Smith', '09992228976', 'not@email.com', 'TTHS', '00000000000', '2021-05-11 16:03:51', '2021-05-11 16:03:51'),
('157762021', 'Michael ', 'douglass', '09186422426', 'michael.douglass23@gmail.com', 'Weekends', '00000000000', '2021-05-12 15:22:30', '2021-05-12 15:22:30'),
('452212021', 'Jose', 'Gaurana', '09237817383', 's@g.com', 'TTHS', '00000000000', '2021-05-12 08:51:57', '2021-05-12 08:51:57'),
('522752021', 'John', 'Smith', '09821756482', 'john@smithh.com', 'MWF', 'password', '2021-05-11 15:58:38', '2021-05-11 15:58:38'),
('548012021', 'Miguel', 'Abundo', '09186422426', 'miguel_abundo@hotmail.com', 'MWF', '00000000000', '2021-05-12 15:02:03', '2021-05-12 15:02:03'),
('669372021', 'Patrick', 'Star', '09996994439', 'patrick_star@gmail.com', 'Weekends', '00000000000', '2021-05-12 16:45:09', '2021-05-12 16:45:09'),
('776312021', 'Steven', 'Smith', '09992228976', 'notyour@email.com', 'TTHS', '00000000000', '2021-05-11 16:04:05', '2021-05-11 16:04:05'),
('816802021', 'ferdinando', 'po', '09274844321', 'ferdinandpo@gmail.com', 'TTh', '12345', '2021-05-10 10:19:26', '2021-05-10 10:49:21'),
('934932021', 'paul', 'ine', '09274844321', 'paul.ine@gmail.com', 'MWF', '12345', '2021-05-10 10:18:16', '2021-05-10 10:18:16');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `membership_id` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `member_id` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `purchase_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `membership_id`, `member_id`, `purchase_date`) VALUES
('211015839', '198231', '202119992', '2021-05-03 07:36:31'),
('211037849', '198233', '202126330', '2021-03-05 14:22:45'),
('211042813', '198232', '202192046', '2021-02-02 05:40:21'),
('211047321', '198232', '202167544', '2021-03-13 17:22:45'),
('211047389', '198231', '202192046', '2021-04-02 19:27:12'),
('211047531', '198233', '202119992', '2021-04-30 10:41:26'),
('211048439', '198232', '202192046', '2021-02-06 18:30:36'),
('211053202', '198231', '202126330', '2021-05-03 09:32:40'),
('211056798', '198232', '202119992', '2021-05-10 14:27:39'),
('211056799', '198231', '202119992', '2021-01-14 11:27:26'),
('211056800', '198231', '202126330', '2021-02-20 11:31:47'),
('211057982', '198232', '202167544', '2021-03-31 09:36:35'),
('211058954', '198232', '202119992', '2021-06-10 14:29:25'),
('211059798', '198233', '202192046', '2021-05-02 10:25:43'),
('211061873', '198231', '202192046', '2021-01-09 09:39:03'),
('211066798', '198232', '202167544', '2021-03-11 16:30:10'),
('211074831', '198232', '202192046', '2021-05-08 20:25:43'),
('211078150', '198232', '202119992', '2021-07-10 14:27:30'),
('211083590', '198233', '202167544', '2021-05-11 23:32:39'),
('211084287', '198232', '202119992', '2021-08-10 14:29:24'),
('211084327', '198232', '202192046', '2021-01-25 07:37:33'),
('211084556', '198232', '202126330', '2021-05-10 15:06:50'),
('211085349', '198231', '202119992', '2021-05-03 04:31:26'),
('211097398', '198232', '202119992', '2021-09-10 14:29:22'),
('211215934', '198231', '202135790', '2021-05-12 17:00:21'),
('211216455', '198231', '202135790', '2021-05-12 17:08:41'),
('211217298', '198232', '202118050', '2021-05-12 17:15:29'),
('211218490', '198232', '202118050', '2021-05-12 17:12:30'),
('211219352', '198231', '202135790', '2021-05-12 17:09:35'),
('211222016', '198232', '202118050', '2021-05-12 17:18:28'),
('211223144', '198231', '202135790', '2021-05-12 17:05:06'),
('211227048', '198233', '202135790', '2021-05-12 17:03:17'),
('211234257', '198231', '202135790', '2021-05-12 15:44:21'),
('211235328', '198231', '202135790', '2021-05-12 17:08:01'),
('211248253', '198232', '202119992', '2021-05-12 17:13:57'),
('211263706', '198231', '202135790', '2021-05-12 15:44:13'),
('211265593', '198231', '202135790', '2021-05-12 17:13:00'),
('211267778', '198232', '202118050', '2021-05-12 17:12:51'),
('211268881', '198231', '202164131', '2021-05-12 16:29:26'),
('211280422', '198232', '202118050', '2021-05-12 17:27:05'),
('211280490', '198231', '202135790', '2021-05-12 17:05:38'),
('211281806', '198232', '202118050', '2021-05-12 17:18:09'),
('211286650', '198232', '202118050', '2021-05-12 17:15:07'),
('211288777', '198232', '202118050', '2021-05-12 17:13:54'),
('211290976', '198231', '202135790', '2021-05-12 17:03:38'),
('211293243', '198232', '202118050', '2021-05-12 17:18:38'),
('211294589', '198231', '202135790', '2021-05-12 15:43:37'),
('211298458', '198231', '202135790', '2021-05-12 17:09:19'),
('211299515', '198231', '202135790', '2021-05-12 17:08:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `membership_plan`
--
ALTER TABLE `membership_plan`
  ADD PRIMARY KEY (`membership_id`);

--
-- Indexes for table `trainer`
--
ALTER TABLE `trainer`
  ADD PRIMARY KEY (`trainer_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
