<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// files
include_once '../config/connection.php';
include_once '../objects/trainer.php';

// connection
$database = new Database();
$db = $database->getConnection();

// object
$trainer = new Trainer($db);

// inputs
$data = json_decode(file_get_contents("php://input"));
$load_trainer = null;

if (!empty($data->oldEmail)) {
	$load_trainer = $data->oldEmail;
	$trainer->load_trainer($load_trainer);
}

// api call
if ($load_trainer != null) {
	if (!empty($data->oldEmail) &&
		!empty($data->firstName) &&
		!empty($data->lastName) &&
		!empty($data->mobileNum) &&
		!empty($data->email) &&
		!empty($data->schedule) &&
		!empty($data->password)){
		$ref_email = $data->oldEmail;
		$first_name = $data->firstName;
		$last_name = $data->lastName;
		$email = $data->email;
		$mobile = $data->mobileNum;
		$schedule = $data->schedule;
		$password = $data->password;
		
		if ($trainer->edit_trainer($ref_email, $first_name, $last_name, $email, $mobile, $schedule, $password)) {
			echo json_encode(array("message" => "Trainer Editted!"));
		} else {
			echo json_encode(array("message" => "Trainer doesn't exist"));
		}
	} else {
		echo json_encode(array("message" => "Unable to edit trainer: Incomplete Request"));
	}
} else {
	echo json_encode(array("message" => "No Trainer Loaded"));
}
?>