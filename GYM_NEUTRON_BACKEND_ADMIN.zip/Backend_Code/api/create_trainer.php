<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// files
include_once '../config/connection.php';
include_once '../objects/trainer.php';

// connection
$database = new Database();
$db = $database->getConnection();

// object
$trainer = new Trainer($db);

// inputs
$data = json_decode(file_get_contents("php://input"));

// api call
if (!empty($data->firstName) &&
	!empty($data->lastName) &&
	!empty($data->email) &&
	!empty($data->mobileNum) &&
	!empty($data->schedule) &&
	!empty($data->password)){
	$first_name = $data->firstName;
	$last_name = $data->lastName;
	$mobile = $data->mobileNum;
	$email = $data->email;
	$schedule = $data->schedule;
	$password = $data->password;
	
	if ($trainer->create_trainer($first_name, $last_name, $mobile, $email, $schedule, $password)) {
		echo json_encode(array("message" => "Trainer Created!"));
	} else {
		echo json_encode(array("message" => "Trainer already exists"));
	}
} else {
	echo json_encode(array("message" => "Unable to create trainer: Incomplete Request"));
}
?>