<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// files
include_once '../config/connection.php';
include_once '../objects/member.php';

// connection
$database = new Database();
$db = $database->getConnection();

// object
$member = new Member($db);

// inputs
$data = json_decode(file_get_contents("php://input"));

// api call
if (!empty($data->memberID)){
	$id = $data->memberID;
	
	if ($member->load_member(null, $id)) {
		echo $member->load_member(null, $id);
	} else {
		echo json_encode(array("message" => "Member does not exist"));
	}
} else {
	echo json_encode(array("message" => "Unable to load member: Incomplete Request"));
}
?>