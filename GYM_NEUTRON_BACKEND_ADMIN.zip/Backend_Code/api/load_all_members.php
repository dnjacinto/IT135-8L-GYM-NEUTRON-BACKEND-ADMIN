<?php
    header('Content-Type: application/json');
	header('Access-Control-Allow-Origin: *');
	
	// files
    include_once '../config/connection.php';
    include_once '../objects/member.php';

    //connection
    $database = new Database();
    $db = $database->getConnection();

    //object
    $member = new Member($db);
	
    //show all members
    $result = $member->load_members();

    echo $result;
?>