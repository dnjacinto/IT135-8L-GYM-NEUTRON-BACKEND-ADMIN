<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// files
include_once '../config/connection.php';
include_once '../objects/transaction.php';

// connection
$database = new Database();
$db = $database->getConnection();

//object
$transaction = new Transaction($db);

//inputs
$data = json_decode(file_get_contents("php://input"));

if(!empty($data->fromDate) && !empty($data->toDate)){
    $to_date = $data->toDate;
    $from_date = $data->fromDate;

    //Show Filtered Transaction Query
    $result = $transaction->readFilter($from_date, $to_date);

    echo $result;
} else {
    //Show All Transaction
    $result = $transaction->read();

    echo $result;
}
?>