<?php
class Database {
	private $host = "localhost";
	private $name = "id16714744_php_db";
	private $password = "Z@lBYXN8eQuqo2hV";
	private $database = "id16714744_project_db";
	private $conn;
	
	public function getConnection() {
		$this->conn = new mysqli($this->host, $this->name, $this->password, $this->database);
		
		if ($this->conn->connect_error) {
			die("Connection failed: " . $this->conn->connect_error);
		}

		//echo "Connected Successfully\n\n";
		return $this->conn;
	}
}
?>